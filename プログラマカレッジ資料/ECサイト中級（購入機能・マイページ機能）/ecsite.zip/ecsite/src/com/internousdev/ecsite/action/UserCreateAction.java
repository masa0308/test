package com.internousdev.ecsite.action;

import com.opensymphony.xwork2.ActionSupport;

public class UserCreateAction extends ActionSupport {

	public String execute() {
		return SUCCESS;
	}
}
